package com.example

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

data class RegionConfig(
    val code: String,
    val displayName: String,
    val currencySymbol: String,
    val appTitle: String,
    val cardTitle: String,
    val labelDistance: String,
    val labelConsumption: String,
    val labelPrice: String,
    val btnCalculateText: String,
    val resultTitle: String,
    val resultFormat: String,
    val btnEcoText: String,
    val ecoDialogTitle: String,
    val ecoDialogMessage: String,
    val toastFillAll: String,
    val toastInvalidNumber: String
)

class MainActivity : AppCompatActivity() {

    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null

    private val adHandler = Handler(Looper.getMainLooper())
    private val interstitialIntervalMs = 120_000L // 2 minutes

    private val interstitialRunnable = object : Runnable {
        override fun run() {
            showInterstitialAd()
            adHandler.postDelayed(this, interstitialIntervalMs)
        }
    }

    private val regions = listOf(
        RegionConfig(
            code = "UA",
            displayName = "🇺🇦 UA (грн ₴)",
            currencySymbol = "грн",
            appTitle = "Калькулятор палива",
            cardTitle = "Параметри поїздки",
            labelDistance = "Відстань поїздки (км)",
            labelConsumption = "Середня витрата палива (л / 100 км)",
            labelPrice = "Ціна за 1 літр палива (грн)",
            btnCalculateText = "РОЗРАХУВАТИ ВАРТІСТЬ",
            resultTitle = "РЕЗУЛЬТАТ РОЗРАХУНКУ",
            resultFormat = "Вартість поїздки: %.2f грн. Необхідно палива: %.2f л",
            btnEcoText = "🌱 Отримати Еко-маршрут (Бонус)",
            ecoDialogTitle = "🌱 Еко-маршрут (Бонус)",
            ecoDialogMessage = "Дякуємо! Ваш бонус: Щоб зекономити до 15% палива, тримайте швидкість 90 км/год та уникайте різких гальмувань.",
            toastFillAll = "Будь ласка, заповніть усі текстові поля!",
            toastInvalidNumber = "Введіть коректні числові значення!"
        ),
        RegionConfig(
            code = "US",
            displayName = "🇺🇸 US ($ USD)",
            currencySymbol = "$",
            appTitle = "Fuel Cost Calculator",
            cardTitle = "Trip Parameters",
            labelDistance = "Trip Distance (km)",
            labelConsumption = "Avg Fuel Consumption (L / 100 km)",
            labelPrice = "Fuel Price per 1 Liter ($ USD)",
            btnCalculateText = "CALCULATE TRIP COST",
            resultTitle = "CALCULATION RESULT",
            resultFormat = "Trip cost: $%.2f. Fuel required: %.2f L",
            btnEcoText = "🌱 Get Eco-Route (Bonus)",
            ecoDialogTitle = "🌱 Eco-Route (Bonus)",
            ecoDialogMessage = "Thank you! Your bonus: To save up to 15% fuel, maintain a steady speed of 90 km/h and avoid sudden braking.",
            toastFillAll = "Please fill in all input fields!",
            toastInvalidNumber = "Please enter valid numeric values!"
        ),
        RegionConfig(
            code = "EU",
            displayName = "🇪🇺 EU (€ EUR)",
            currencySymbol = "€",
            appTitle = "Kraftstoffrechner",
            cardTitle = "Fahrtdaten",
            labelDistance = "Fahrtstrecke (km)",
            labelConsumption = "Durchschnittsverbrauch (l / 100 km)",
            labelPrice = "Kraftstoffpreis pro 1 Liter (€ EUR)",
            btnCalculateText = "KOSTEN BERECHNEN",
            resultTitle = "BERECHNUNGSERGEBNIS",
            resultFormat = "Fahrtkosten: %.2f €. Benötigter Kraftstoff: %.2f l",
            btnEcoText = "🌱 Öko-Route erhalten (Bonus)",
            ecoDialogTitle = "🌱 Öko-Route (Bonus)",
            ecoDialogMessage = "Vielen Dank! Ihr Bonus: Um bis zu 15% Kraftstoff zu sparen, halten Sie eine konstante Geschwindigkeit von 90 km/h ein und vermeiden Sie starkes Bremsen.",
            toastFillAll = "Bitte füllen Sie alle Eingabefelder aus!",
            toastInvalidNumber = "Bitte geben Sie gültige Zahlenwerte ein!"
        ),
        RegionConfig(
            code = "GB",
            displayName = "🇬🇧 UK (£ GBP)",
            currencySymbol = "£",
            appTitle = "Fuel Cost Calculator",
            cardTitle = "Journey Details",
            labelDistance = "Journey Distance (km)",
            labelConsumption = "Avg Fuel Consumption (L / 100 km)",
            labelPrice = "Fuel Price per 1 Litre (£ GBP)",
            btnCalculateText = "CALCULATE COST",
            resultTitle = "CALCULATION RESULT",
            resultFormat = "Trip cost: £%.2f. Fuel required: %.2f L",
            btnEcoText = "🌱 Get Eco-Route (Bonus)",
            ecoDialogTitle = "🌱 Eco-Route (Bonus)",
            ecoDialogMessage = "Thank you! Your bonus: To save up to 15% fuel, maintain a steady speed of 90 km/h and avoid sharp braking.",
            toastFillAll = "Please fill in all fields!",
            toastInvalidNumber = "Please enter valid numbers!"
        ),
        RegionConfig(
            code = "PL",
            displayName = "🇵🇱 PL (zł PLN)",
            currencySymbol = "zł",
            appTitle = "Kalkulator Paliwa",
            cardTitle = "Parametry trasy",
            labelDistance = "Dystans trasy (km)",
            labelConsumption = "Średnie zużycie paliwa (l / 100 km)",
            labelPrice = "Cena za 1 litr paliwa (zł PLN)",
            btnCalculateText = "OBLICZ KOSZT",
            resultTitle = "WYNIK OBLICZEŃ",
            resultFormat = "Koszt przejazdu: %.2f zł. Wymagane paliwo: %.2f l",
            btnEcoText = "🌱 Odbierz Eko-trasę (Bonus)",
            ecoDialogTitle = "🌱 Eko-trasa (Bonus)",
            ecoDialogMessage = "Dziękujemy! Twój bonus: Aby zaoszczędzić do 15% paliwa, utrzymuj prędkość 90 km/h i unikaj gwałtownego hamowania.",
            toastFillAll = "Proszę wypełnić wszystkie pola!",
            toastInvalidNumber = "Wprowadź poprawne wartości liczbowe!"
        ),
        RegionConfig(
            code = "JP",
            displayName = "🇯🇵 JP (¥ JPY)",
            currencySymbol = "¥",
            appTitle = "燃料コスト計算機",
            cardTitle = "走行パラメータ",
            labelDistance = "走行距離 (km)",
            labelConsumption = "平均燃費 (L / 100 km)",
            labelPrice = "1リットルあたりの価格 (円 JPY)",
            btnCalculateText = "コストを計算する",
            resultTitle = "計算結果",
            resultFormat = "旅行費用: ¥%.2f. 必要な燃料: %.2f L",
            btnEcoText = "🌱 エコルートを取得 (ボーナス)",
            ecoDialogTitle = "🌱 エコルート (ボーナス)",
            ecoDialogMessage = "ありがとうございます！ボーナス: 最大15%の燃料を節約するには、時速90kmを維持し、急ブレーキを避けてください。",
            toastFillAll = "すべての入力項目に入力してください！",
            toastInvalidNumber = "有効な数値を入力してください！"
        )
    )

    private var currentRegion: RegionConfig = regions[0]

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. Initialize Google AdMob SDK
        MobileAds.initialize(this) {}

        // 2. Banner Ad (ca-app-pub-3940256099942544/6300978111)
        val adView = findViewById<AdView>(R.id.adView)
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)

        // 3. Load Interstitial & Rewarded Ads
        loadInterstitialAd()
        loadRewardedAd()

        // Automatically show Interstitial Ad every 2 minutes
        adHandler.postDelayed(interstitialRunnable, interstitialIntervalMs)

        // View Bindings
        val tvAppTitle = findViewById<TextView>(R.id.tvAppTitle)
        val tvCardTitle = findViewById<TextView>(R.id.tvCardTitle)
        val lblDistance = findViewById<TextView>(R.id.lblDistance)
        val lblConsumption = findViewById<TextView>(R.id.lblConsumption)
        val lblPrice = findViewById<TextView>(R.id.lblPrice)
        val etDistance = findViewById<EditText>(R.id.etDistance)
        val etConsumption = findViewById<EditText>(R.id.etConsumption)
        val etPrice = findViewById<EditText>(R.id.etPrice)
        val btnCalculate = findViewById<Button>(R.id.btnCalculate)
        val tvResultTitle = findViewById<TextView>(R.id.tvResultTitle)
        val tvResult = findViewById<TextView>(R.id.tvResult)
        val btnEcoRoute = findViewById<Button>(R.id.btnEcoRoute)
        val spinnerLanguage = findViewById<Spinner>(R.id.spinnerLanguage)

        // Setup Language Spinner
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            regions.map { it.displayName }
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerLanguage.adapter = adapter

        fun updateUiLanguage(config: RegionConfig) {
            currentRegion = config
            tvAppTitle.text = config.appTitle
            tvCardTitle.text = config.cardTitle
            lblDistance.text = config.labelDistance
            lblConsumption.text = config.labelConsumption
            lblPrice.text = config.labelPrice
            btnCalculate.text = config.btnCalculateText
            tvResultTitle.text = config.resultTitle
            btnEcoRoute.text = config.btnEcoText

            // Recalculate if values already typed
            val distance = etDistance.text.toString().toDoubleOrNull()
            val consumption = etConsumption.text.toString().toDoubleOrNull()
            val price = etPrice.text.toString().toDoubleOrNull()
            if (distance != null && consumption != null && price != null) {
                val neededFuel = (distance * consumption) / 100.0
                val tripCost = neededFuel * price
                tvResult.text = config.resultFormat.format(tripCost, neededFuel)
            } else {
                tvResult.text = config.resultFormat.format(0.0, 0.0)
            }
        }

        spinnerLanguage.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position in regions.indices) {
                    updateUiLanguage(regions[position])
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Calculation logic on button click
        btnCalculate.setOnClickListener {
            val distanceStr = etDistance.text.toString().trim()
            val consumptionStr = etConsumption.text.toString().trim()
            val priceStr = etPrice.text.toString().trim()

            if (distanceStr.isEmpty() || consumptionStr.isEmpty() || priceStr.isEmpty()) {
                Toast.makeText(this, currentRegion.toastFillAll, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val distance = distanceStr.toDoubleOrNull()
            val consumption = consumptionStr.toDoubleOrNull()
            val price = priceStr.toDoubleOrNull()

            if (distance == null || consumption == null || price == null) {
                Toast.makeText(this, currentRegion.toastInvalidNumber, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val neededFuel = (distance * consumption) / 100.0
            val tripCost = neededFuel * price

            tvResult.text = currentRegion.resultFormat.format(tripCost, neededFuel)
        }

        // Eco-route Bonus Button logic
        btnEcoRoute.setOnClickListener {
            showRewardedAd()
        }
    }

    private fun loadInterstitialAd() {
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            this,
            "ca-app-pub-3940256099942544/1033173712",
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                }
            }
        )
    }

    private fun showInterstitialAd() {
        interstitialAd?.let { ad ->
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitialAd()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    loadInterstitialAd()
                }
            }
            ad.show(this)
        } ?: run {
            loadInterstitialAd()
        }
    }

    private fun loadRewardedAd() {
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            this,
            "ca-app-pub-3940256099942544/5224354917",
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                }
            }
        )
    }

    private fun showRewardedAd() {
        val currentAd = rewardedAd
        if (currentAd != null) {
            currentAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewardedAd()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    loadRewardedAd()
                    showEcoBonusDialog()
                }
            }
            currentAd.show(this) { _ ->
                showEcoBonusDialog()
            }
        } else {
            showEcoBonusDialog()
            loadRewardedAd()
        }
    }

    private fun showEcoBonusDialog() {
        AlertDialog.Builder(this)
            .setTitle(currentRegion.ecoDialogTitle)
            .setMessage(currentRegion.ecoDialogMessage)
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onDestroy() {
        adHandler.removeCallbacks(interstitialRunnable)
        super.onDestroy()
    }
}

